-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2019 at 03:13 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminsignup`
--

CREATE TABLE IF NOT EXISTS `adminsignup` (
  `username` varchar(200) NOT NULL,
  `email` varchar(155) NOT NULL,
  `password` varchar(44) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminsignup`
--

INSERT INTO `adminsignup` (`username`, `email`, `password`, `img`) VALUES
('masum', 'masum.pust43@gmail.com', 'masum', 'img.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
`id` int(100) NOT NULL,
  `cat_name` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`) VALUES
(1, 'php'),
(2, 'bootstrap'),
(3, 'Fundamentals Of Computer CSE-1101'),
(4, 'Programing with C CSE-1103'),
(5, 'Programming with C Sessional CSE-1104'),
(6, 'Physics PHY-1101');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
`id` int(100) NOT NULL,
  `question` varchar(80) NOT NULL,
  `ans1` varchar(80) NOT NULL,
  `ans2` varchar(80) NOT NULL,
  `ans3` varchar(80) NOT NULL,
  `ans4` varchar(80) NOT NULL,
  `ans` int(4) NOT NULL,
  `cat_id` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `ans1`, `ans2`, `ans3`, `ans4`, `ans`, `cat_id`) VALUES
(1, 'What does PHP stand for?', 'Private home page', 'Personal Hypertext preprocessor', 'Hypertext Preprocessor', 'Hypertext Prepare', 1, 1),
(2, 'How do you write "Hello World" in PHP?', 'echo "Hello World";', 'Hello World', 'document.write("Hello World");', 'print("Hello World");', 0, 2),
(3, 'HTML means????', 'HyperText Markup Language', 'Hyper Text Markup Local', 'HyperText Manual Language', 'HyperTestMarkup Language', 0, 1),
(4, 'URL means????', 'uniform resource locator', 'union resource location', 'universal reason loaction', 'universal reason loactor', 0, 1),
(5, 'PHP server scripts are surrounded by delimiters, which?', '&lt;?php ...?&gt;', '&lt;?php  &lt;/?&gt;', '&lt;script&gt;&lt;/script&gt;', '&lt;php&gt;&lt;/php&gt;', 0, 1),
(6, 'All variables in PHP start with which symbol?', '$', '!', '?', '&lt;', 0, 2),
(7, 'Which one of these variables has an illegal name?', '$myVar', '$myVar', '$my_Var', '$my--Var', 3, 1),
(8, 'Which one of these variables has an illegal name?', '$myVar', '$myVar', '$my_Var', '$my--Var', 3, 2),
(9, '', '', '', '', '', 0, 0),
(10, 'First operating system designed using C programming language.', 'DOS', 'UNIX', 'WINDOWS', 'MAC', 1, 3),
(11, '#include<stdio.h>\r\n\r\nmain()\r\n{\r\n   printf("%d", -11%2);\r\n}', '1', '-1', '5.5', '-5.5', 1, 3),
(12, 'What is the built in library function to compare two strings?', 'A - string_cmp()\r\n\r\n\r\n', ' strcmp()', 'equals()', ' str_compare()', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
`id` int(255) NOT NULL,
  `username` varchar(155) NOT NULL,
  `session` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1150135 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `session`, `email`, `password`, `img`) VALUES
(150120, 'sakil', '2014-16', 'sakil@gmail.com', 'sakil', 'cam3.jpg'),
(150121, 'asikh', '2015-16', 'asikh@gmail.com', 'asik', 'hjuipngpng.png'),
(150142, 'hakkani', '2015-16', 'shaju.pust43@gmail.com', '', 'C:xampp	mpphpF1B7.tmp'),
(150143, 'masum', 'session', 'email', 'password', 'C:xampp	mpphp3BA1.tmp'),
(150145, 'masum', '2014-15', 'masum.pust42@gmail.com', 'masum', 'hjuipngpng.png'),
(150147, 'shaju', '2014-15', 'masum.pust43@gmail.com', 'shaju', 'img13.jpg'),
(150149, 'Rasel', '2014-15', 'Rasel.pust47@gmail.com', 'rasel', 'img12.jpg'),
(150156, 'Delower', '2014-15', 'delower@gmail.com', 'delower', 'cam3.jpg'),
(1150134, 'shuvo', '2014-18', 'shuvo.pust42@gmail.com', 'shuvo', 'C:xampp	mpphpFA90.tmp');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1150135;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
