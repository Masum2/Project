<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <title>Allah Is Almighty</title>
  </head>
  <body>

    <!--navbar-->
    <div class="container">
    <nav class="navbar navbar-expand-lg">
  


  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
       <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="registration.php">Registration</a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="#">Contact</a>
      </li>
    
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
</div>
  <!--end navbar-->
    <!--slider-->
    <div class="container">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/pic1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/pic2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/pic3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
<!--end slider-->
<!--marque-->
<div class="container">
<div class="marque">
  <p><marquee>Welcome To Computer Science & Engineering Department,PUST</marquee></p>
  </div>
</div>
<div class="container">
<div class="content">
  <h3 style="text-align: center; color: blue;">About Department Of Computer Science And Engineering,PUST.</h3>
  <p>The Department of Computer Science and Engineering (CSE) is one of the initial department at the Pabna University of Science & Technology. The department provides an outstanding opportunity to students to get quality education in Computer Science & Engineering. It started its academic activities from 2009. Since then, it has been widely recognized for its excellent research and teaching capabilities. The graduates from the department are heavily recruited by both academia and industry of home and abroad The Department provides an outstanding research environment complemented by superior teaching for its students to flourish in. Within this period of time, the department produced many undergraduate research works, which were published in some world-recognized journals/Conference(s). The major areas of research include Algorithms, Soft Computing, Mobile Robotics, Artificial Intelligence, Speech Processing, Natural Language Processing, Image Processing, Software Engineering, VLSI Design, Embedded Systems, Data Mining, Machine Learning, Distributed computing, Computer Arithmetic, Computer Systems & Security, Networks. Besides theoretical research, faculty in the department also maintain strong ties with many reputed national and international companies and are involved in a large number of projects in the forefronts of cutting edge technology. The student bodies of the department namely Computer Science and Engineering Association (CSEA) in association with local IEEE student branch is active in organizing regular workshops/seminars, lecture series, and practical demos. The CSEA organizes programming contests regularly to prepare themselves for the ACM collegiate and other programming contests. They are also devoted to the sports and cultural activities of this university. </p>
  </div>
</div>
<div class="container">
 <footer class="footer">
  <div class="row">
    <div class="col-sm-12">
   <p>copyright masum.pust43@gmail.com</p>
   </div>
 </div>
 </footer>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>