<?php
include("class/user.php");
$qus = new users;
$cat = $_POST['cat'];
$qus->qus_show($cat);
$_SESSION['cat']=$cat;
//echo"<pre>";
//print_r($qus->qus);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script type="text/javascript">
    	function timeout()
    	{   
    		var hours=Math.floor(timeLeft/3600);
    		var minute=Math.floor((timeLeft-(hours*60*60)-30)/60);
    		var second = timeLeft%60;
    		var hrs = checktime(hours);
    		var mint = checktime(minute);
    		var sec = checktime(second);
    		if(timeLeft<=0)
    		{   clearTimeout(tm);
    			document.getElementById("form1").submit();
    		}
    		else
    		{    
    			
    			document.getElementById("time").innerHTML=hrs+":"+mint+":"+sec;
    		}
    		timeLeft--;
    		var tm=setTimeout(function(){timeout()},1000);
    	}
    	function checktime(msg)
    	{
           if(msg<10){
           	msg="0"+msg;
           }
           return msg;
    	}
    </script>

    <title>Allah Is Almighty</title>
  </head>
  <body onload="timeout()">
    <div class="container">
    <nav class="navbar navbar-expand-lg ">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>


  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
       <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="#">Registration</a>
      </li>

      <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="contact.php">Contact</a>
      </li>
     <li class="nav-item">
        <a class="nav-link btn btn-outline-primary" href="admin/login.php">Admin</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
</div>
<div class="container">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/cam1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/cam2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/cam3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
<div class="container">
<div class="marque">
  <p><marquee>Department Of Computer Science & Engineering</marquee></p>
  
</div>
</div>
<div class="container">
<div class="tbcontent">
<div class="col-sm-2"></div> 
<div class="col-sm-8"> 
<h2>Online quiz
<script type="text/javascript">
	var timeLeft = 5*60;
</script>

<div id="time" style="float: right;">Timeout</div></h2>
<?php 
$i=1;
foreach($qus->qus as $qust) {?> 
<form method="post" id="form1" action="answer.php">     
  <table class="table table-info">
    <thead>
      <tr>
        <th><?php echo $i;?>&emsp;<?php echo $qust['question'];?></th>
      </tr>
    </thead>
    <tbody>
    	<?php if(isset($qust['ans1'])){?>
      <tr>
        <td>&nbsp;1&emsp;<input type="radio" value="0" name="<?php echo $qust['id'];?>"/>&nbsp;<?php echo $qust['ans1'];?></td>
      </tr>
  <?php }?>
  <?php if(isset($qust['ans2'])){?>
       <tr>
        <td>&nbsp;2&emsp;<input type="radio" value="1" name="<?php echo $qust['id'];?>"/>&nbsp;<?php echo $qust['ans2'];?></td>
      </tr>
      <?php }?>
      <?php if(isset($qust['ans3'])){?>
       <tr>
        <td>&nbsp;3&emsp;<input type="radio" value="2" name="<?php echo $qust['id'];?>"/>&nbsp;<?php echo $qust['ans3'];?></td>
      </tr>
      <?php }?>
       <?php if(isset($qust['ans4'])){?>
       <tr>
        <td>&nbsp;4&emsp;<input type="radio" value="3" name="<?php echo $qust['id'];?>"/>&nbsp;<?php echo $qust['ans4'];?></td>
      </tr>
       <?php }?>
    
       <tr>
        <td><input type="radio" checked="checked" style="display:none"value="no_attemp" name="<?php echo $qust['id'];?>"/></td>
      </tr>
   
    </tbody>
  </table>
<?php $i++; }?>
<center><input type="submit" value="submit" class="btn btn-info"></center>
</form>
</div>
<div class="col-sm-2"></div> 

</div>
</div>
<br>
<div class="container">
 <footer class="footer">
  <div class="row">
    <div class="col-sm-12">
   <p>copyright masum.pust43@gmail.com</p>
   </div>
 </div>
 </footer>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>