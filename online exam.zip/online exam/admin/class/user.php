<?php
session_start();
class users{
	public $host = "localhost";
	public $username ="root";
	public $pass ="";
	public $db_name = "project";
	public $conn;
	public $data;


	public function __construct()
	{
		$this->conn = new mysqli($this->host,$this->username,$this->pass,$this->db_name);
		if($this->conn->connect_errno)
		{
			die("database connectio failed".$this->conn->connect_errno);
		}
	}

	public function signup($data){

       $this->conn->query($data);
       return true;
	}
	public function signin($email,$pass){
          $query=$this->conn->query("select email,password from adminsignup where email='$email' and password='$pass'");
      
      $query->fetch_array(MYSQLI_ASSOC);
      if($query->num_rows>0)
      {
      	$_SESSION['email'] = $email;
      	return true;
      }
      else{
      	return false;
      }
	}
		public function user_profile($email){
      $query=$this->conn->query("select * from adminsignup where email='$email' ");
      while($row=$query->fetch_array(MYSQLI_ASSOC))
    
      {
      $this->data[]=$row;
      }
      return $this->data;
     

	}
      public function url($url)
      {
            header("location:".$url);
      }
	
}


?>