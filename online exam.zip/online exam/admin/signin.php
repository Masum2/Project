<?php
include("class/user.php");
$signin=new users;
extract($_POST);
if($signin->signin($e,$p)){
	$signin->url("index.php");
}
else{
	$signin->url("login.php?run=failed");
}

?>