<?php 
include("class/user.php");

$register = new users;
extract($_POST);
$img_name = $_FILES['img']['name'];
$tmp_name = $_FILES['img']['tmp_name'];
move_uploaded_file($tmp_name,"img/".$img_name);
$query ="insert into signup values('$id','$username','$session','$email','$pass','$img_name')";
if($register->signup($query))
{
	$register->url("login.php?run=success");
}


?>